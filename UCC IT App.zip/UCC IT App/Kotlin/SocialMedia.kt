package com.example.studentmanagement

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_social_media.*


class SocialMedia : AppCompatActivity() {




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_social_media)
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)





        instagram.setOnClickListener {

            loadUrlInWebView("https://www.instagram.com/uccjamaica/")
        }

        twitter.setOnClickListener {
            loadUrlInWebView("https://twitter.com/UCCjamaica")
        }

        facebook.setOnClickListener {
            loadUrlInWebView("https://www.facebook.com/uccjamaica")
        }
    }

    private fun loadUrlInWebView(url: String) {
        val webView = WebView(this)
        // Enable JavaScript (optional)
        webView.settings.javaScriptEnabled = true
        webView.webViewClient = WebViewClient()
        webView.loadUrl(url)

        setContentView(webView)
    }
}




