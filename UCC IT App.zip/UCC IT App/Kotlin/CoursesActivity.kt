package com.example.studentmanagement

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CoursesActivity : AppCompatActivity() {
    private lateinit var courseDBHelper: CoursesDatabaseHelper
    private lateinit var coursesRecyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.courses_activity)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)

        courseDBHelper = CoursesDatabaseHelper(this)
        coursesRecyclerView = findViewById(R.id.coursesRecyclerView)

        coursesRecyclerView.layoutManager = LinearLayoutManager(this)
        coursesRecyclerView.adapter = CourseAdapter(courseDBHelper.getAllCourses() as MutableList<Course>)

        // Add a new course
        courseDBHelper.insertCourse(Course("ITT101", "Programming Techniques", 3, null, "An introduction to programming concepts with python"))
        courseDBHelper.insertCourse(Course("ITT102", "Internet Authoring", 3, "ITT101", "An introduction to web development using HTML, CSS and JavaScript"))
        courseDBHelper.insertCourse(Course("ITT103", "Database Management Systems", 3, "ITT101", "An introduction to database concepts and SQL"))
        courseDBHelper.insertCourse(Course("ITT201", "Object-Oriented Programming", 3, "ITT101", "A deep dive into object-oriented programming concepts and design patterns"))
        courseDBHelper.insertCourse(Course("ITT202", "Mobile App Development", 3, "ITT101", "An introduction to mobile app development using Android or iOS"))
        courseDBHelper.insertCourse(Course("ITT203", "Data Structures and Algorithms", 3, "ITT101", "A study of fundamental data structures and algorithms"))
        courseDBHelper.insertCourse(Course("ITT301", "Discrete Math I", 3, "ITT201", "course teaches the students techniques in how to think logically and mathematically and apply these techniques in solving problems."))
        courseDBHelper.insertCourse(Course("ITT302", "Computer Networks", 3, "ITT101", "An introduction to computer networks and network programming"))
        courseDBHelper.insertCourse(Course("ITT303", "Computer Graphic Design", 3, "ITT103", "An introduction to Graphic design elements using photoshop"))
        courseDBHelper.insertCourse(Course("ITT401", "Discrete Math II", 3, "ITT201, ITT203", "Aims to be a Addition for things learnt in Discrete Maths I"))

        // Add the courses to the RecyclerView
        (coursesRecyclerView.adapter as CourseAdapter).addAllCourses(courseDBHelper.getAllCourses())
    }

    override fun onDestroy() {
        super.onDestroy()
        courseDBHelper.close()
    }
}
