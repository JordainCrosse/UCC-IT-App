package com.example.studentmanagement



import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class CoursesDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(CREATE_COURSE_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun insertCourse(course: Course) {
        val values = ContentValues().apply {
            put(COLUMN_CODE, course.code)
            put(COLUMN_NAME, course.name)
            put(COLUMN_CREDITS, course.credits)
            put(COLUMN_PREREQUISITES, course.prerequisites)
            put(COLUMN_DESCRIPTION, course.description)
        }
        writableDatabase.insert(TABLE_NAME, null, values)
    }

    @SuppressLint("Range")
    fun getAllCourses(): List<Course> {
        val courses = mutableListOf<Course>()
        val cursor = readableDatabase.query(
            TABLE_NAME, null, null, null, null, null, null
        )
        cursor.use {
            while (cursor.moveToNext()) {
                val code = cursor.getString(cursor.getColumnIndex(COLUMN_CODE))
                val name = cursor.getString(cursor.getColumnIndex(COLUMN_NAME))
                val credits = cursor.getInt(cursor.getColumnIndex(COLUMN_CREDITS))
                val prerequisites = cursor.getString(cursor.getColumnIndex(COLUMN_PREREQUISITES))
                val description = cursor.getString(cursor.getColumnIndex(COLUMN_DESCRIPTION))
                val course = Course(code, name, credits, prerequisites, description)
                courses.add(course)
            }
        }
        return courses
    }

    companion object {
        private const val DATABASE_NAME = "course.db"
        private const val DATABASE_VERSION = 1

        const val TABLE_NAME = "courses"
        const val COLUMN_CODE = "code"
        const val COLUMN_NAME = "name"
        const val COLUMN_CREDITS = "credits"
        const val COLUMN_PREREQUISITES = "prerequisites"
        const val COLUMN_DESCRIPTION = "description"

        private const val CREATE_COURSE_TABLE = """
            CREATE TABLE $TABLE_NAME (
                $COLUMN_CODE TEXT PRIMARY KEY,
                $COLUMN_NAME TEXT,
                $COLUMN_CREDITS INTEGER,
                $COLUMN_PREREQUISITES TEXT,
                $COLUMN_DESCRIPTION TEXT
            )
        """
    }
}
