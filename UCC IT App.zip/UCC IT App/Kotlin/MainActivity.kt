package com.example.studentmanagement

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById(R.id.toolbar))



        // Find the toolbar view inside the activity layout
        val toolbar: Toolbar = findViewById(R.id.toolbar)
// Sets the Toolbar to act as the ActionBar for this Activity window.
// Make sure the toolbar exists in the activity and is not null
        setSupportActionBar(toolbar)

        // Menu icons are inflated just as they were with actionbar
        fun onCreateOptionsMenu(menu: Menu): Boolean {
            // Inflate the menu; this adds items to the action bar if it is present.
            menuInflater.inflate(R.menu.menu_main, menu)
            return true
        }


        // Get the button view
        val faculty = findViewById<View>(R.id.faculty)


        // Set a click listener on the button
        faculty.setOnClickListener {
            // Create an intent to open the Faculty activity
            val intent = Intent(this, StaffDirectory::class.java)
            startActivity(intent)
        }

        // Get the button view
        val admission = findViewById<View>(R.id.admissions)


        // Set a click listener on the button
        admission.setOnClickListener {
            // Create an intent to open the Faculty activity
            val intent = Intent(this, Admissions::class.java)
            startActivity(intent)
        }


        // Get the button view
        val socials = findViewById<View>(R.id.socials)


        // Set a click listener on the button
        socials.setOnClickListener {
            // Create an intent to open the Faculty activity
            val intent = Intent(this, SocialMedia::class.java)
            startActivity(intent)
        }

        // Get the button view
        val courses = findViewById<View>(R.id.Courses)


        // Set a click listener on the button
        courses.setOnClickListener {
            // Create an intent to open the Faculty activity
            val intent = Intent(this, CoursesActivity::class.java)
            startActivity(intent)
        }


        // Get the FAB view
        val fab = findViewById<FloatingActionButton>(R.id.fab)

        // Set a click listener on the FAB
        fab.setOnClickListener {
            // Create an intent to open the Gmail app
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:") // Only email apps should handle this
                putExtra(
                    Intent.EXTRA_EMAIL,
                    arrayOf("ithod@ucc.edu.jm")
                ) // Set the recipient email address
            }
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent) // Open the Gmail app
            }
        }


    }



}

