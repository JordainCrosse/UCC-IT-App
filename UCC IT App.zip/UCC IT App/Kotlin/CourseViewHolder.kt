package com.example.studentmanagement


import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CourseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val courseCodeTextView = itemView.findViewById<TextView>(R.id.courseCodeTextView)
    private val courseNameTextView = itemView.findViewById<TextView>(R.id.courseNameTextView)
    private val courseCreditsTextView = itemView.findViewById<TextView>(R.id.courseCreditsTextView)
    private val coursePrerequisitesTextView = itemView.findViewById<TextView>(R.id.coursePrerequisitesTextView)
    private val courseDescriptionTextView = itemView.findViewById<TextView>(R.id.courseDescriptionTextView)

    @SuppressLint("SetTextI18n")
    fun bind(course: Course) {
        courseCodeTextView.text = course.code
        courseNameTextView.text = course.name
        courseCreditsTextView.text = "Credits: ${course.credits}"
        coursePrerequisitesTextView.text = "Prerequisites: ${course.prerequisites ?: "None"}"
        courseDescriptionTextView.text = course.description
    }


}
