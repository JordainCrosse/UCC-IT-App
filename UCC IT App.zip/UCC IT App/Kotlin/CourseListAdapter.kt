package com.example.studentmanagement

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class CourseListAdapter(context: Context, courses: List<Course>) :
    ArrayAdapter<Course>(context, 0, courses) {

    @SuppressLint("SetTextI18n")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view = convertView
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.item_course, parent, false)
        }

        val course = getItem(position)

        val courseCodeTextView = view!!.findViewById<TextView>(R.id.course_code_textview)
        val courseNameTextView = view.findViewById<TextView>(R.id.course_name_textview)
        val courseCreditsTextView = view.findViewById<TextView>(R.id.course_credits_textview)
        val coursePrereqsTextView = view.findViewById<TextView>(R.id.course_prereqs_textview)
        val courseDescriptionTextView =
            view.findViewById<TextView>(R.id.course_description_textview)

        courseCodeTextView.text = course?.code
        courseNameTextView.text = course?.name
        courseCreditsTextView.text = "Credits: ${course?.credits}"
        coursePrereqsTextView.text = "Prerequisites: ${course?.prerequisites?.joinToString(", ")}"
        courseDescriptionTextView.text = course?.description
        return view
    }
}
