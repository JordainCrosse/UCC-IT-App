package com.example.studentmanagement

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View


class StaffDirectory : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_staff_directory)
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)


        // Get the button view
        val email1 = findViewById<View>(R.id.staff_email_button1)

// Set a click listener on the button
        email1.setOnClickListener {
            // Create an intent to open the Gmail app
            val intent1 = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:") // Only email apps should handle this
                putExtra(
                    Intent.EXTRA_EMAIL,
                    arrayOf("itprogrammeofficer@ucc.edu.jm")
                ) // Set the recipient email address
            }
            if (intent1.resolveActivity(packageManager) != null) {
                startActivity(intent1) // Open the Gmail app
            }


        }

        // Get the button view
        val email2 = findViewById<View>(R.id.staff_email_button2)

        // Set a click listener on the button
        email2.setOnClickListener {
            // Create an intent to open the Gmail app
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:") // Only email apps should handle this
                putExtra(
                    Intent.EXTRA_EMAIL,
                    arrayOf("itfaculty@ucc.edu.jm")
                ) // Set the recipient email address
            }
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent) // Open the Gmail app
            }
        }


        // Get the button view
        val email3 = findViewById<View>(R.id.staff_email_button3)

        // Set a click listener on the button
        email3.setOnClickListener {
            // Create an intent to open the Gmail app
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:") // Only email apps should handle this
                putExtra(
                    Intent.EXTRA_EMAIL,
                    arrayOf("itprogrammeofficer3@ucc.edu.jm")
                ) // Set the recipient email address
            }
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent) // Open the Gmail app
            }
        }


        // Get the button view
        val email4 = findViewById<View>(R.id.staff_email_button4)

        // Set a click listener on the button
        email3.setOnClickListener {
            // Create an intent to open the Gmail app
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:") // Only email apps should handle this
                putExtra(
                    Intent.EXTRA_EMAIL,
                    arrayOf("bchang@faculty.ucc.edu.jm")
                ) // Set the recipient email address
            }
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent) // Open the Gmail app
            }
        }

        // Get the button view
        val email5 = findViewById<View>(R.id.staff_email_button5)

        // Set a click listener on the button
        email5.setOnClickListener {
            // Create an intent to open the Gmail app
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:") // Only email apps should handle this
                putExtra(
                    Intent.EXTRA_EMAIL,
                    arrayOf("ithod@ucc.edu.jm")
                ) // Set the recipient email address
            }
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent) // Open the Gmail app
            }
        }



    }

    fun onCallButtonClicked(view: View) {
        val phoneNumber = "876-548-0629"
        if (phoneNumber.isNotEmpty()) {
            val callIntent = Uri.parse("tel:$phoneNumber").let { number ->
                Intent(Intent.ACTION_DIAL, number)
            }
            startActivity(callIntent)

        }
    }

    fun onCallButtonClicked1(view: View) {
        val phoneNumber = "(876) 906-3000"
        if (phoneNumber.isNotEmpty()) {
            val callIntent = Uri.parse("tel:$phoneNumber").let { number ->
                Intent(Intent.ACTION_DIAL, number)
            }
            startActivity(callIntent)

        }
    }

    fun onCallButtonClicked2(view: View) {
        val phoneNumber = "(876) 906-3000"
        if (phoneNumber.isNotEmpty()) {
            val callIntent = Uri.parse("tel:$phoneNumber").let { number ->
                Intent(Intent.ACTION_DIAL, number)
            }
            startActivity(callIntent)

        }
    }

    fun onCallButtonClicked3(view: View) {
        val phoneNumber = "876-802-4572"
        if (phoneNumber.isNotEmpty()) {
            val callIntent = Uri.parse("tel:$phoneNumber").let { number ->
                Intent(Intent.ACTION_DIAL, number)
            }
            startActivity(callIntent)

        }
    }

    fun onCallButtonClicked4(view: View) {
        val phoneNumber = "876-339-0961"
        if (phoneNumber.isNotEmpty()) {
            val callIntent = Uri.parse("tel:$phoneNumber").let { number ->
                Intent(Intent.ACTION_DIAL, number)
            }
            startActivity(callIntent)

        }
    }
}

